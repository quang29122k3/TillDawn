CREATE DATABASE tilldawn;

USE tilldawn;

CREATE TABLE role (
  id BIGINT(20) NOT NULL AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  code VARCHAR(255) NOT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE person (
    id VARCHAR(20) PRIMARY KEY,
    password VARCHAR(100) NOT NULL,
    class VARCHAR(255),
    fullname VARCHAR(255) DEFAULT NULL,
    is_active BOOLEAN DEFAULT 1,  -- 1 là kích hoạt, 0 là bị chặn
    role_id BIGINT(20),
    FOREIGN KEY (role_id) REFERENCES role(id)
);

CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255),
    total_copies INT DEFAULT 1,   -- tổng số bản sao của sách
    available INT DEFAULT 1,      -- số lượng sách hiện còn
    image VARCHAR(500)
);

CREATE TABLE loans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    person_id VARCHAR(20),
    book_id INT,
    borrow_date DATE NOT NULL,
    return_date DATE,
    returned BOOLEAN DEFAULT 0,   -- 0 là chưa trả, 1 là đã trả
    status VARCHAR(20) DEFAULT 'borrowed',  -- borrowed, returned, overdue
    FOREIGN KEY (person_id) REFERENCES person(id),
    FOREIGN KEY (book_id) REFERENCES books(id)
);

ALTER TABLE tilldawn.books MODIFY image VARCHAR(255) NULL;
ALTER TABLE tilldawn.books MODIFY title VARCHAR(255) NULL;
ALTER TABLE person 
ADD COLUMN reset_code VARCHAR(6),
ADD COLUMN reset_code_expiry TIMESTAMP NULL;
ALTER TABLE person
ADD COLUMN email VARCHAR(255) NOT NULL;
